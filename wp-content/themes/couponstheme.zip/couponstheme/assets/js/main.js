$(document).ready(function() {

    
    var debounceTimer;
    var siteUrl = 'http://localhost:8888/VishwajitWeb/couponswebsite';

    $('#headerSearch').on('keypress', function() {
        clearTimeout(debounceTimer); // Clear the previous timer

        var inputValue = $(this).val();
        debounceTimer = setTimeout(function() {
        callAPI(inputValue); // Make the API call after the debounce delay
        }, 300); // Adjust the debounce delay (in milliseconds) as needed
    });

    function callAPI(value) {
        
        if (value) {
        $.ajax({
            url: 'http://140.238.244.200/kws__by__query?q=' + value,  // Replace with your actual API endpoint
            method: 'GET',  // Use the   HTTP method (GET/POST)
            dataType: 'json',  // Adjust the data type according to your response
            success: function(response) {
            var results = '';
            $.each(response.results, function(index, item) {
                console.log(item)
            results += '<li><a href="'+siteUrl+'/keyword?q=' + item['keyword_slug'] + '">' + item['keyword'] + '</li>';
            });
            // console.log(results)
            $('#resultsList').html(results);
            },
            error: function() {
            console.log('Error occurred during API call.');
            }
        });
        }
    }
    

});