<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Best Coupons and Deals for DealsTodayIndia.com</title>
    <meta name="description"
        content="Discover the latest coupons, discounts, and deals from top brands at DealsTodayIndia.com. Save money on your online purchases with our wide selection of offers.">
    <meta name="keywords" content="coupons, deals, discounts, promo codes, online shopping, savings">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://DealsTodayIndia.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(). '/dist/style.css' ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    <script src="<?php echo get_stylesheet_directory_uri(). '/dist/app.js' ?>"></script>

    <?php wp_head(); 
    ?>
</head>
<body class="home-wrapper">
    <header>
        <div class="container">
        <div class="row">
        <div class="header-inner">
        <div class="header-left">
        <logo>
            <a href="/"><span>DealsTodayIndia.com</span></a>
        </logo>    
        <nav>
            <ul>
                <li><a href="<?php echo get_site_url(); ?>/about-us">About</a></li>
                <li><a href="<?php echo get_site_url(); ?>/privacy">Privacy</a></li>
                <li><a href="<?php echo get_site_url(); ?>/contact">Contact</a></li>
                <li><a href="<?php echo get_site_url(); ?>/blogs">Blogs</a></li>
            </ul>
        </nav>
        </div>
        <div class="header-right">
        <div class="header-search">
            <form action="">
                <input id="headerSearch" type="text" placeholder="find offers and coupons">
                <ul id="resultsList" class="resultsList"></ul>
            </form>
        </div>
        </div>
        </div>
        </div>
        </div>
    </header>
    <header-secondary>
        <div class="container">
        <div class="row">
        <div class="header-secondary">
        <nav class="secondary-nav">
            <ul>
                <li><a href="<?php echo get_site_url(); ?>/store/amazon">amazon</a></li>
                <li><a href="<?php echo get_site_url(); ?>/store/flipkart">flipkart</a></li>
                <li><a href="<?php echo get_site_url(); ?>/hot-offers">Hot offers</a></li>                
            </ul>
        </nav>
        </div>
        </div>
        </div>
    </header-secondary>    
    <content>