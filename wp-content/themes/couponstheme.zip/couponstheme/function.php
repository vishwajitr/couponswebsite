<?php

// function get_posts_from_rest_api() {
//     $url = 'http://140.238.244.200/search/offer__by__store__slug?q=amazon'; // Replace with your WordPress site URL

//     $response = wp_remote_get($url);
//     print_r($response);

//     if (!is_wp_error($response) && $response['response']['code'] === 200) {
//         $data = json_decode($response['body'], true);
//         echo 'API Response: ' . print_r($data, true);
//     } else {
//         echo 'Failed to retrieve posts.';
//     }
// }

// get_posts_from_rest_api();

