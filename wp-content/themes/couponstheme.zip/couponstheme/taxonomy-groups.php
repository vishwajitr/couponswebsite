<?php 
include('apicalls.php');
get_header(); ?>

<div class="store-page">
<div class="container">
<h2 class="store-page-title">Search For "<?php echo $page_title;?>"</h2>
<p class="store-page-description">
Attention tech enthusiasts! Don't miss out on the incredible offer available at Amazon, Flipkart, and various online stores. Get your hands on the latest flagship smartphones with discounts of up to 40%. Whether you're an Apple fan or an Android lover, this deal has something for everyone. Upgrade your device and enjoy cutting-edge features without breaking the bank. Hurry, as this offer won't last long!
</p>
<div class="container">
<div class="row leftright-content-row">
<div class="left-container">   

    <?php if ( have_posts() ) : 
        while ( have_posts() ) :
        the_post();
        $link = preg_replace('~<p[^>]*>~', '', get_the_excerpt());

        ?>
        <div class="deal__card">
        <div class="deal__discount">
            <div class="deal__info">
                <div>
                    <?php the_content();?>
                </div>
            </div>
        </div>
        <div class="deal__desc">
            <div class="deal__desc-type"></div>
            <div class="deal__desc-title">
                <h3>
                <a target="_blank" rel="nofollow" href="<?php the_permalink(); ?>">
                <?php the_title(); ?>
                    </a>
                </h3>
            </div>
            <div class="deal__desc-meta">
                <span class="deal__desc-meta-lastused">
                    <i class="fa fa-users"></i>&nbsp;<b>73</b> People Used Today
                </span>                
            </div>
            <div class="deal__cta">
                <div><a target="_blank" rel="nofollow" href="<?php echo $link; ?>">Get This Deal</a></div>
            </div>
        </div>
        </div>
        <?php
      endwhile;
      the_posts_navigation();
      else :
          echo '<p>No content found.</p>';
      endif;
    ?>
</div>
<div class="right-container">
<?php include_once('includes/keywordBlock.php'); ?>
</div> 
</div> 

</div>
</div>
</div>

<?php get_footer(); ?>
